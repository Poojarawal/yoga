<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Yogapose;

class YogaController extends Controller
{
    public function yogaposelist(){
        $yogapose = Yogapose::all();
        return $yogapose;
    }
}
