<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Yogapose extends Model
{
    protected $table = 'yoga_poses';
}
